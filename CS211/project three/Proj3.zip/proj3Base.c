#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 10
#define FALSE 0
#define TRUE  1

int DebugMode;



typedef struct mazeStruct
{
 //char arr[32][32];  /* allows for a maze of size 30x30 plus outer walls */
 char **arr;
 int xsize, ysize;
 int xstart, ystart;
 int xend, yend;
} maze;

typedef struct mazeStack // maze stack definition...
{
	int xValue;
	int yValue;
	struct mazeStack* next;
} stack;

typedef stack* stackPtr; // typedef to shorthand double stars...

void init(stackPtr* head) // initialize the head...
{
	head = NULL;
}// end init...

void push(stackPtr* head, int dataX, int dataY) // push function for LL stack...
{
	stackPtr tmp = (stackPtr)malloc(sizeof(stack));
	tmp->xValue = dataX;
	tmp->yValue = dataY;
	tmp->next = *head;
	*head = tmp;
}// end push...

void pop(stackPtr *head) // pop function for LL stack...
{
	stackPtr tmp = *head;
	*head = (*head)->next;
	free(tmp);
}// end pop...

int isEmpty (stackPtr hd) // function checks for empty LL stack...
{
 if (hd == NULL)
 {
   return TRUE;
 }
 else
 {
   return FALSE;
 }
}// end isEmpty...

void peek(stackPtr head,int nodeCounter) // function peeks at the top of the stack...
{

	printf("X = %d  ", head->xValue);
	printf("Y = %d  \n", head->yValue);
}//end peek....

void clear(stackPtr head) // function clears the LL stack for reuse...
{
	while(!isEmpty(head))
	{
		pop(&head);
	}
}

int main (int argc, char **argv)
{
  stackPtr head = NULL; // declare the head locally....
  maze m1; // maze declaration...
	
	DebugMode = FALSE;
	
	int q;
	int nodeCounter = 1;

	

  int xpos, ypos;
  int i,j;

  FILE *src;
	


  /* verify the proper number of command line arguments were given */
  if(argc > 3) {
     fprintf(stderr,"Usage: %s <input file name>\n", argv[0]);
     exit(-1);
  }
	
  for(q=0;q<argc ; q++)
  {
	  if(strcmp(argv[q],"-d") == 0)
	  {
		  DebugMode = TRUE;
	  }
  }
   
  /* Try to open the input file. */
  if ( ( src = fopen( argv[1], "r" )) == NULL && (src = fopen(argv[2],"r")) == NULL)
  {
    printf ( "Can't open input file: %s", argv[1] );
    exit(-1);
  }

  /* read in the size, starting and ending positions in the maze */
  fscanf (src, "%d %d", &m1.xsize, &m1.ysize);
  /* print them out to verify the input */
  while(m1.xsize <= 0 || m1.ysize <= 0) // input file attempts to assign a size less than or equal to zero... 
  {
	  fprintf(stderr, "                   ==>Invalid: Maze sizes must be greater than 0 \n" );
	  fscanf (src, "%d %d", &m1.xsize, &m1.ysize);
	  
	  

  }
  fscanf (src, "%d %d", &m1.xstart, &m1.ystart);

  while(m1.xstart > m1.xsize || m1.ystart > m1.ysize) // input file assigns a start position too large for size...
  {
	  fprintf(stderr, "                   ==>Invalid: start position exceeds size \n");
	  fscanf (src, "%d %d", &m1.xstart, &m1.ystart);
	  

  }
  fscanf (src, "%d %d", &m1.xend, &m1.yend);
  while(m1.xsize < m1.xend || m1.ysize < m1.yend) // input file assigns an end position to large for size...
  {
	  fprintf(stderr, "                   ==>Invalid: end position exceeds size\n");
	  fscanf (src, "%d %d", &m1.xend, &m1.yend);

  }
  printf ("PROGRAM INFO: CS211 PROJECT 3 OF FALL 2019, SKELETON PROVIDED BY PROFFESOR NASIM MOBASHERI AND MODIFIED BY MYSELF,JOSEPH LENAGHAN\n\n");
  printf ("the purpose of this program is to accept maze parameters and then, using a DFS algorithm, calculate a path out of the maze\n");
  printf ("--------------------------------------------------------------------------------------------------------------------\n\n");
  printf ("size: %d, %d\n", m1.xsize, m1.ysize);
  printf ("start: %d, %d\n", m1.xstart, m1.ystart);
  printf ("end: %d, %d\n", m1.xend, m1.yend);
	
	

	
	
   /* allocate the maze */
  m1.arr = (char **) malloc (sizeof(char *) * (m1.xsize+2) );
  for (i = 0; i < m1.xsize+2; i++)
  {
     m1.arr[i] = (char *) malloc (sizeof(char ) * (m1.ysize+2) );
  }
  /* initialize the maze to empty */
  for (i = 0; i < m1.xsize+2; i++)
     for (j = 0; j < m1.ysize+2; j++)
       m1.arr[i][j] = '.';

  /* mark the borders of the maze with *'s */
  for (i=0; i < m1.xsize+2; i++)
    {
     m1.arr[i][0] = '*';
     m1.arr[i][m1.ysize+1] = '*';
    }
  for (i=0; i < m1.ysize+2; i++)
    {
     m1.arr[0][i] = '*';
     m1.arr[m1.xsize+1][i] = '*';
    }

  /* mark the starting and ending positions in the maze */
  m1.arr[m1.xstart][m1.ystart] = 's';
  m1.arr[m1.xend][m1.yend] = 'e';
		  
  /* mark the blocked positions in the maze with *'s */
  while (fscanf (src, "%d %d", &xpos, &ypos) != EOF)
    {
	 if((xpos > m1.xsize) || (xpos > m1.ysize) || (ypos > m1.xsize) || (ypos > m1.ysize)) // checks for whether or not column is in range...
	 {
		 fprintf(stderr,"                   ==>Invalid:Attempted to place column outside of range...\n");
	 }
	 if((xpos == m1.xstart) && (ypos == m1.ystart) || (xpos == m1.xend) && (ypos > m1.yend)) // check to see if columns block star or end...
	 {
		 fprintf(stderr,"                   ==>Invalid:Attempted to place column on the start or end of the maze...\n");
	 }
     m1.arr[xpos][ypos] = '*';
    }
	/* set unvisited locations...*/
   for (i = 0; i < m1.xsize+2; i++)
	{
	  for(j = 0; j < m1.ysize+2; j++)
		{
		   if(m1.arr[i][j] == '.')
			{
			  m1.arr[i][j] = 'X';
			}
		}
	}

  /* print out the initial maze */
  for (i = 0; i < m1.xsize+2; i++)
    {
     for (j = 0; j < m1.ysize+2; j++)
       printf ("%c", m1.arr[i][j]);
     printf("\n");
  }
	
  push(&head,m1.xstart,m1.ystart); // push the star of the maze onto the stack...
  m1.arr[m1.xstart][m1.ystart] = 'Y'; // set the star of the maze to visited...
  ////////////////////////////
  // DEPTH FIRST SEARCH ALG
  // 
  // Algorithm checks for neighbors whilst also checking for the exit, if a valid neighbor is found it pushed and marked visited..
 ////////////////////
 while(m1.arr[head->xValue][head->yValue] != m1.arr[m1.xend][m1.yend])
 {
	 if(m1.arr[head->xValue+1][head->yValue] == 'X' || m1.arr[head->xValue+1][head->yValue] == 'e')
	 {
		push(&head,head->xValue+1,head->yValue);
		if(DebugMode == TRUE)
	     {
		
		    printf("current Node %d: ",nodeCounter);
		    nodeCounter++;
 	     } 
		peek(head,nodeCounter);
		m1.arr[head->xValue][head->yValue] = 'Y';
	 }
	 else if(m1.arr[head->xValue][head->yValue-1] == 'X' || m1.arr[head->xValue][head->yValue-1] == 'e')
	 {
		 push(&head,head->xValue,head->yValue-1);
		 if(DebugMode == TRUE)
	     {
		
		    printf("current Node %d: ",nodeCounter);
		    nodeCounter++;
 	     } 
		 peek(head,nodeCounter);
		 m1.arr[head->xValue][head->yValue] = 'Y';
	 }
	 else if(m1.arr[head->xValue][head->yValue+1] == 'X' || m1.arr[head->xValue][head->yValue+1] == 'e')
	 {
		 push(&head,head->xValue,head->yValue+1);
		 if(DebugMode == TRUE)
	     {
		
		    printf("current Node %d: ",nodeCounter);
		    nodeCounter++;
 	     } 
		 peek(head,nodeCounter);
		 m1.arr[head->xValue][head->yValue] = 'Y';		 
	 }
	 else if(m1.arr[head->xValue-1][head->yValue] == 'X' || m1.arr[head->xValue-1][head->yValue] == 'e' )
	 {
		 push(&head,head->xValue-1,head->yValue);
		 if(DebugMode == TRUE)
	     {
		
		    printf("current Node %d: ",nodeCounter);
		    nodeCounter++;
 	     } 
		 peek(head,nodeCounter);
		 m1.arr[head->xValue][head->yValue] = 'Y';
	 }
	 else
	 {
		 if(DebugMode == TRUE)
	     {
		
		    printf("popped Node %d: ",nodeCounter);
			peek(head,nodeCounter);
		    nodeCounter--;
 	     } 
		 pop(&head); // neighbors are either visited or blocked, so pop...
	 }
	 if(isEmpty(head) == 1) // check for empty stack...
	 {
		 printf("Maze has no solution, Exiting....\n");
		 exit(0);
	 }
	 
 }
//////////////////////////
//END ALG
/////////////////////////
 
	
}
