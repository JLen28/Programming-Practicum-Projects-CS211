#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef enum {FALSE = 0, TRUE = 1, NO = 0, YES = 1} boolean;
//
int DebugMode;

typedef struct NODE{
	char* name;
	int burger;
	int salad;
	int status; // status 1 means in the restaurant, 0 means opposite...
	struct NODE* Next;
		 
}node;

typedef struct Queue{
	node* front;
	node* rear;
}queue;

typedef node* nodePtr;

/////////////////Functions forward defined below/////////////////
void clearToEoln();

int getNextNWSChar();

int getPosInt();

char *getName();

void printCommands();

void doAdd (queue* q);

void doCallAhead (queue* q);

void doWaiting (queue* q);

void doRetrieve (queue* q);

void doList (queue* q);

void doDisplay (queue* q);

void doEstimateTime(queue* q);

nodePtr newNode(char* n, int b, int s, int status);

queue* newQueue();

int doesNameExist(queue* q, char* n);

void addToList(queue* q,char* name, int b, int s, int status);

void updateStatus(queue* q,char* n);

char* retrieveandRemove(queue* q,int b, int s);

int countOrdersAhead(queue* q,char* n);

int displayWaitingTime(queue* q, char* n);

void displayOrdersAhead(queue* q, char* n);

void displayListInformation(queue* q);

