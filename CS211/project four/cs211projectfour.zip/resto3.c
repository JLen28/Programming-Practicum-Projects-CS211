#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "header.h"


/* node initializer... */
////////////////////////////////////////////////
nodePtr newNode(char* n, int b, int s, int status)
{
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp->name = n;
	tmp->burger = b;
	tmp->salad = s;
	tmp->status = status;
	return tmp;
}
/*queue initializer... */
////////////////////////////////////////////////
queue* newQueue()
{
	queue* q = (queue*)malloc(sizeof(queue));
	q->front = q->rear = NULL;
	return q;
}
/*does the name exist already or not, if 1 is returned this accounts for true while zero accounts for false */
//////////////////////////////////////////////////////////////////////////
int doesNameExist(queue* q, char* n)
{
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	while(tmp != NULL)
	{
		if(DebugMode == TRUE)
		{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		}	
		if(strcmp(tmp->name,n) == 0)
		{
			return 1;
		}
		else{
			tmp = tmp->Next;
		}
		
	}
	return 0;
}
/*adds a new a new node onto the end of the linked list */
//////////////////////////////////////////////////////////
void addToList(queue* q,char* name, int b, int s, int status)
{
	//create a new node with relevant information
	nodePtr tmp = newNode(name,b,s,status);
	if(DebugMode == TRUE)
	{
	  printf("--------------------------");
	  printf("\n");
	  printf("Order Name: \"%s\" \n", tmp->name);
	  printf("Burgers: %d \n", tmp->burger);
	  printf("Salads: %d \n", tmp->salad);
	  if(tmp->status == 1)
	  {
		  printf("Currently waiting...");
	  }
	  else
	  {
		  printf("Call ahead order..");
	  }
	  printf("\n");
	  printf("--------------------------");
	  printf("\n");
	}
	if(tmp->burger == 0 && tmp->salad == 0)
	{
		printf("Error: no freeloaders!!...");
		return;
	}
	if(q->rear == NULL) // queue is empty...
	{
		q->front = q->rear = tmp;
		return;
	}
	q->rear->Next = tmp;
	q->rear = tmp;


}
/*changes the status from call ahead to waiting*/
/////////////////////////////////////////////////
void updateStatus(queue* q,char* n)
{
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	while(tmp != NULL)
	{
		if(DebugMode == TRUE)
		{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		}
		if(strcmp(tmp->name,n) == 0)
		{
			if(tmp->status == 0)
			{
				tmp->status = 1;
				return;
			}
			else
			{
				printf("Error: order is already waiting! Returning...");
				return;
			}
		}
		else
		{
			tmp = tmp->Next;			
		}
	}
	printf("Error: Name does not exist in Order List, Returning...");
	return;
}
/*finds the first restaurant order that matches the order ready for pickup */
/////////////////////////////////////////////////////////////////////////////
char* retrieveandRemove(queue* q,int b, int s)
{
	if (q->front == NULL)
	{
		printf("Error: Order List does not exist...");
		return NULL;
	}
	if((q->front->burger == b) && (q->front->salad == s) && (q->front->status == 1))
	{
		char* result = q->front->name;
		q->front = q->front->Next;
		return result;
	}
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	nodePtr tmp2 = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	tmp2 = q->front->Next;
	while(tmp2 != NULL)
	{
		if(DebugMode == TRUE)
		{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		}
		if((tmp2->burger == b) && (tmp2->salad == s)) // correct # of burgers and salds...
		{
			if(tmp2->status == 1) // the order is in the restaurant...
			{
				char* result = tmp2->name;
				if(tmp2->Next != NULL){
					free(tmp2);
					tmp->Next = tmp2->Next;
					return result;
				}
				tmp2 = NULL;
				tmp->Next = NULL;
				free(tmp2);
				q->rear = tmp;
				return result;
			}
			else
			{
				tmp2 = tmp2->Next;
				tmp = tmp->Next;
			}
			
		}
		else
		{
			tmp2 = tmp2->Next;
			tmp = tmp->Next;
		}
	}
	printf("Error: name not found waiting! Returning...\n");
	return NULL;
}
/*function counts the orders ahead of a specific order */
/////////////////////////////////////////////////////////////////////////////
int countOrdersAhead(queue* q,char* n)
{
	int counter = 0;
	if((strcmp(q->front->name,n)) == 0)
	{
		return counter;
	}
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	while((strcmp(tmp->name,n) != 0))
	{
		if(tmp == NULL)
		{
			printf("Error: name not found waiting! Returning...");
			return 0;
		}
		if(DebugMode == TRUE)
		{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		}
		if(tmp->Next == NULL)
		{
	      return 0;
		}
		tmp = tmp->Next;
		counter++;
	}


	return counter;
	
}
/* functions displays the waiting time for a specific order */
///////////////////////////////////////////////////////////////
int displayWaitingTime(queue* q, char* n)
{
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	int bCount = 0;
	int sCount = 0;
	while(tmp != NULL)
	{
		if(DebugMode == TRUE)
		{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		}
		if(strcmp(tmp->name,n) == 0)
		{
			bCount = 10 * tmp->burger;
			sCount = 5 * tmp->salad;
			int result = bCount + sCount;
			return result;
		}
		else
		{
			tmp = tmp->Next;
		}
		
	}
	printf("Error: Name does not exist in Order List, Returning...");
	return 0;	
}
/* functions displays each order as it traverses to a specific order */
///////////////////////////////////////////////////////////////////////
void displayOrdersAhead(queue* q, char* n)
{
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	while((strcmp(tmp->name,n) != 0))
	{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		tmp = tmp->Next;
	}
	return;
}
/* functions displays every single order in the order list */
/////////////////////////////////////////////////////////////
void displayListInformation(queue* q)
{
	nodePtr tmp = (nodePtr)malloc(sizeof(node));
	tmp = q->front;
	while(tmp != NULL)
	{
		printf("--------------------------");
		printf("\n");
		printf("Order Name: \"%s\" \n", tmp->name);
		printf("Burgers: %d \n", tmp->burger);
		printf("Salads: %d \n", tmp->salad);
		if(tmp->status == 1)
		{printf("Currently waiting...");
		}
		else
		{
			printf("Call ahead order..");
		}
		printf("\n");
		printf("--------------------------");
		printf("\n");
		
		tmp = tmp->Next;		
	}
}