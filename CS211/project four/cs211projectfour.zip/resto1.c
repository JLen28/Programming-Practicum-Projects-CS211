#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "header.h"



/////////////////////////////////
/* main that handles the user interaction and selection*/
int main (int argc, char **argv)
{
 node* head = NULL;
 queue* q = newQueue();
 char *input;
 int ch;
 DebugMode = FALSE;
	
 int i;
	
 for(i= 0; i<argc;i++)
 {
	 if(strcmp(argv[i],"-d") == 0)
		 DebugMode = TRUE;
 }
	

	

 printf("PROGRAM INFO: CS211 PROJECT 4 OF FALL 2019, SKELETON PROVIDED BY PROFFESOR NASIM MOBASHERI AND MODIFIED BY MYSELF, JOSEPH LENAGHAN\n\n");
 printf("program simulates a restaurant ticket system, in this case, the restaurant serves burgers and salads, utilize the '?' command to get a list of commands\n");
 printf("--------------------------------------------------------------------------------------------------------------\n\n");
 printf ("Starting Fast Food Order Management Program\n\n");
 printf ("Enter command: ");

 while ((ch = getNextNWSChar ()) != EOF)
   {
    /* check for the various commands */
    if ('q' == ch)
      {
       printf ("Quitting Program\n");
       return (0);
      }
    else if ('?' == ch)
      {
       printCommands();
      }
    else if('a' == ch)
      {
       doAdd(q);
      } 
    else if('c' == ch)
      {
       doCallAhead(q);
      } 
    else if('w' == ch)
      {
       doWaiting(q);
      } 
    else if('r' == ch)
      {
       doRetrieve(q);
      } 
    else if('l' == ch)
      {
       doList(q);
      } 
    else if('d' == ch)
      {
       doDisplay(q);
      } 

    else if('t' == ch)
      {
      	doEstimateTime(q);
      }	
      
    else if('\n' == ch)
      {
       /* nothing entered on input line     *
        * do nothing, but don't give error  */
      } 
    else
      {
       printf ("%c - in not a valid command\n", ch);
       printf ("For a list of valid commands, type ?\n");
       clearToEoln();
      }

    printf ("\nEnter command: ");
   }

 printf ("Quiting Program - EOF reached\n");
 return 1;
}
/*grabs input from the user and parts it out for storage and traversal purposes */
///////////////////////////////////////////////////////////
void clearToEoln()
{
 int ch;
 
 do {
     ch = getc(stdin);
    }
 while ((ch != '\n') && (ch != EOF));
}
/* further input manipulation */
///////////////////////////////////////////////////////////
int getNextNWSChar ()
{
 int ch;

 ch = getc(stdin);
 if (ch == EOF || ch == '\n')
   return ch;
 while (isspace (ch))
   {
    ch = getc(stdin);
    if (ch == EOF || ch == '\n')
      return ch;
   }
 return ch;
}
/* retrieve an integer value from the input line */
//////////////////////////////////////////////////////////
int getPosInt ()
{
 int value = -1;

 /* clear white space characters */
 int ch;
 ch = getc(stdin);
 while (!isdigit(ch))
   {
    if ('\n' == ch)  /* error \n ==> no integer given */
       return -1;
    if (!isspace(ch)) /* error non white space ==> integer not given next */
      {
       clearToEoln();
       return -1;
      }
    ch = getc(stdin);
   }

 value = ch - '0';
 ch = getc(stdin);
 while (isdigit(ch))
   {
    value = value * 10 + ch - '0';
    ch = getc(stdin);
   }

 ungetc (ch, stdin);  /* put the last read character back in input stream */

 /* Integer value less than 0 is an error in this program */
 if (0 > value)
    clearToEoln();
   
 return value;
}
/* get the name from the input for storage and manipulation */
/////////////////////////////////////////////////////////
char *getName()
{
 /* skip over the white space characters */
 int ch;
 ch = getc(stdin);
 while (isspace(ch))
   {
    if ('\n' == ch)  /* error \n ==> no integer given */
       return NULL;
    ch = getc(stdin);
   }

 char *word;
 int size;
 size = 10;
 word = (char *) malloc (sizeof(char) * size);
  
 // read in character-by-character until the newline is encountered
 int count = 0;

 while (ch != '\n')
   {
    if (count+1 >= size)
      {
       // to grow an array to make it "dynamically sized" using malloc
       char* temp;
       int i;
       size = size * 2;
       temp = (char *) malloc (sizeof(char) * size);
    
       // copy the characters to the new array
       for (i = 0 ; i < count ; i++)
           temp[i] = word[i];

       free (word);
       word = temp;
      }

    word[count] = ch;
    count++;
    word[count] = '\0';

    // read next character
    ch = getc(stdin);
   }

 if (count > 30)
   {
    count = 30;
    word[count] = '\0';
   }
 
 /* clear ending white space characters */
 while (isspace (word[count-1]))
   {
    count--;
    word[count] = '\0';
   }

 return word;
}
/* print all the possible user inputs for this program */
//////////////////////////////////////////////////////
void printCommands()
{
 printf ("The commands for this program are:\n\n");
 printf ("q - to quit the program\n");
 printf ("? - to list the accepted commands\n");
 printf ("a <# burgers> <# salads> <name> - to add your order to the order list\n");
 printf ("c <# burgers> <# salads> <name> - to add a call-ahead order to the order list\n");
 printf ("w <name> - to specify a call-ahead group is now waiting in the restaurant\n");
 printf ("r <# burgers> <# salads> - to retrieve the first waiting group whose order matches the items on the counter\n");
 printf ("l <name> - list how many orders are ahead of the named order\n");
 printf ("d - display the order list information\n");
 printf ("t <name> - display an estimated wait time for the given order name\n");
       
 /* clear input to End of Line */
 clearToEoln();
}
////////////////////////////////////////////////////
