#include <cstdio>
#include <cstring>
#include <cctype>
#include <stdio.h>

 class intStack
 {
		private:
		int* dyArr;
		int Allocated;
		int inUse;

		public:
		void init();
		int isEmpty();
		void push(int data);
		int top();
		void pop();
		void reset();
 };

 class charStack
 {
		private:
		char* dyArr;
		int Allocated;
		int inUse;

		public:
		void init();
		int isEmpty();
		void push(char data);
		char top();
		void pop();
		void reset();
 };
