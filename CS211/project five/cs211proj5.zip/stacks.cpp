#include "stacks.h"
//
//
//
////////////////// INTEGER STACK DEFINITION //////////////////////////////

 void intStack::init()// initialize the int stack...
 {
	 Allocated = 2;
	 inUse = 0;
	 dyArr = new int [Allocated];
 }// end init...
/*I decided for isEmpty to be an int instead of a bool as logically, they are the same*/
 int intStack::isEmpty()// if the inUse is zero, we know the function is Empty...
 {
	 if(inUse == 0)
	 {
		 return 1; // one means true....
	 }
	 else
	 {
		 return 0; // zero means false...
	 }
	 
 }// end isEmpty..

 void intStack::push(int data) // accepts data and pushes into the dynamic array of the int stack...
 {
	 if(inUse > Allocated)
	 {
		 int* tmp = dyArr;
		 dyArr = new int [Allocated + 2];
		 for(int a = 0; a < inUse; a++)
		 {
			 dyArr[a] = tmp[a];
		 }
		 delete tmp;
		Allocated = Allocated + 2;
	 }
	 dyArr[inUse] = data;
	 inUse++;
 }// end push...

 int intStack::top() // grab and return the top of the int stack...
 {
	 if(this->isEmpty() == 1)
	 {

		 return -1;
		 
	 }
	 return dyArr[inUse - 1];
 }// end top...

 void intStack::pop()//pop the top of the int stack...
 {
	if(this->isEmpty() == 1)
	{

		 return;		 
	}
	 inUse--;
	 
 }// end pop...
 void intStack::reset() // reset the int stack for re-use..
 {
	 Allocated = 2;
	 inUse = 0;
	 dyArr = new int [Allocated];
 } // end reset...
//////////////// END INTEGER STACK DEFINITION //////////////////////////////
//
//////////////// CHARACTER STACK DEFINITION //////////////////////////////

 typedef charStack* charStackPtr;

 void charStack::init() // initialize the character stack...
 {
	 Allocated = 2;
	 inUse = 0;
	 dyArr = new char [Allocated];
 }// end init...
 /*I decided for isEmpty to be an int instead of a bool as logically, they are the same*/
 int charStack::isEmpty() // if the inUse is zero, we know the function is Empty...
 {
	 if(inUse == 0)
	 {
		 return 1; // one means true....
	 }
	 else
	 {
		 return 0; // zero means false...
	 }
	 
 }// end isEmpty...

 void charStack::push(char data) // accepts data and pushes into the dynamic array of the char stack...
 {
	 if(inUse > Allocated)
	 {
		 char* tmp = dyArr;
		 dyArr = new char [Allocated + 2];
		 for(int a = 0; a < inUse; a++)
		 {
			 dyArr[a] = tmp[a];
		 }
		 delete tmp;
		Allocated = Allocated + 2;
	 }
	 dyArr[inUse] = data;
	 inUse++;
 }// end push...

 char charStack::top() // grab and return the top of the char stack...
 {
	 if(this->isEmpty() == 1)
	 {

		 return -1;
		 
	 }
	 return dyArr[inUse - 1];
 }// end top...

 void charStack::pop() // pop the top of the char stack...
 {
	if(this->isEmpty() == 1)
	{

		 return;		 
	}
	 inUse--;
	 
 }// end pop...
 void charStack::reset() // reset the char stack for re-use...
 {
	 Allocated = 2;
	 inUse = 0;
	 dyArr = new char [Allocated];
 }// end reset...
//////////////// END CHARACTER STACK DEFINITION //////////////////////////////